<?php
class Verification {
    function random_text($type = 'alnum', $length = 8) {
        switch ($type) {
            case 'alnum':
                $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            case 'alpha':
                $pool = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            case 'hexdec':
                $pool = '0123456789abcdef';
                break;
            case 'numeric':
                $pool = '0123456789';
                break;
            case 'nozero':
                $pool = '123456789';
                break;
            case 'distinct':
                $pool = '2345679ACDEFHJKLMNPRSTUVWXYZ';
                break;
            default:
                $pool = (string) $type;
                break;
        }
        $crypto_rand_secure = function ( $min, $max ) {
            $range = $max - $min;
            if ($range < 0)
                return $min; // not so random...
            $log = log($range, 2);
            $bytes = (int) ( $log / 8 ) + 1; // length in bytes
            $bits = (int) $log + 1; // length in bits
            $filter = (int) ( 1 << $bits ) - 1; // set all lower bits to 1
            do {
                $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
                $rnd = $rnd & $filter; // discard irrelevant bits
            } while ($rnd >= $range);
            return $min + $rnd;
        };
        $token = "";
        $max = strlen($pool);
        for ($i = 0; $i < $length; $i++) {
            $token .= $pool[$crypto_rand_secure(0, $max)];
        }
        return $token;
    }
//end function
    function rand_password() {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&(){}[]*+-=@_|";
        $random_str = substr(str_shuffle($chars), 0, 1);
        $lower_letters = "abcdefghijklmnopqrstuvwxyz";
        $random_str .= substr(str_shuffle($lower_letters), 0, 2);
        $random_str .= substr(str_shuffle($chars), 0, 1);
        $digits = "0123456789";
        $random_str .= substr(str_shuffle($digits), 0, 2);
        $random_str .= substr(str_shuffle($chars), 0, 1);
        $upper_letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $random_str .= substr(str_shuffle($upper_letters), 0, 2);
        $random_str .= substr(str_shuffle($chars), 0, 1);
        $special_chars = "!#$%&(){}[]*+-=@_|";
        $random_str .= substr(str_shuffle($special_chars), 0, 1);
        $random_str .= substr(str_shuffle($chars), 0, 1);
        return $random_str;
    }
    function secured_hash($input) {
        $output = password_hash($input, PASSWORD_DEFAULT);
        return $output;
    }
//end function
    function passwordcheck($input, $hash) {
        if (password_verify($input, $hash)) {
            // echo 'Password is valid!';
            return true;
        } else {
            return false;
        }
    }
//end function
}
?>