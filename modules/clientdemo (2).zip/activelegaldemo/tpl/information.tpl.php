<!-- start page content wrapper-->
<?php $isEdit = !empty($edit_id); ?>
<div class="page-content-wrapper">

    <!-- start page content-->

    <div class="page-content">


        <!--start breadcrumb-->

        <div class="d-flex justify-content-between align-items-center mb-3">

            <!-- Breadcrumb on the Left -->

            <div class="page-breadcrumb d-none d-sm-flex align-items-center">

                <div class="breadcrumb-title pe-3">Dashboard</div>

                <div class="ps-3">

                    <nav aria-label="breadcrumb">

                        <ol class="breadcrumb mb-0 p-0 align-items-center">

                            <li class="breadcrumb-item">

                                <a href="javascript:;" id="home-icon">

                                    <ion-icon name="home-outline" title="Back to Dashboard"></ion-icon>

                                </a>

                            </li>

                            <li class="breadcrumb-item active" aria-current="page">Active Legal Information</li>

                        </ol>

                    </nav>

                </div>

            </div>

            <!-- Back Button on the Right -->

            <?php include "common/backButton_list.php"; ?>

        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <div class="row">

            <div class="col col-lg-12 mx-auto">

                <?php if ($data['error']) { ?>

                    <div class="alert alert-dismissible fade show py-2 bg-danger" id="divErrorMsg">

                        <div class="d-flex align-items-center">

                            <div class="fs-3 text-white"><ion-icon name="close-circle-sharp"></ion-icon>

                            </div>

                            <div class="ms-3">

                                <div class="text-white"><?= $data['error'] ?></div>

                            </div>

                        </div>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

                    </div>

                <?php } ?>



                <div class="card">

                    <div class="card-body">

                        <ul class="nav nav-tabs nav-primary" role="tablist">

                            <?php

                            echo createNavItem(

                                "activelegaldemo",

                                "Information",

                                "information-sharp",

                                "information",

                                $edit_id,

                                true

                            ); // Active tab

                            echo createNavItem(

                                "activelegaldemo",

                                "Documents",

                                "document-attach-sharp",

                                "document",

                                $edit_id

                            ); // Inactive tab



                            echo createNavItem(

                                "activelegaldemo",

                                "Contact",

                                "person-add-outline",

                                "contact",

                                $edit_id

                            ); // Inactive tab



                            echo createNavItem(

                                "activelegaldemo",

                                "Commission",

                                "cash",

                                "commission",

                                $edit_id

                            );




           



                            // Inactive tab

                            ?>



                        </ul>

                        <div class="tab-content py-3">

                            <div class="tab-pane fade show active" id="primaryhome" role="tabpanel">

                                <form action="" method="post" id="frm_activelegal_information"

                                    name="frm_activelegal_information" enctype="multipart/form-data">

                                    <!--start shop cart-->

                                    <section class="shop-page">

                                        <div class="shop-container">

                                            <div class="shop-cart">

                                                <div class="container">

                                                    <div class="row">

                                                        <div class="col-lg-6">

                                                            <div class="col">

                                                                <div class="card">

                                                                    <div class="card-header">

                                                                        <h6 class="mb-0"><i class="lni lni-user"></i>

                                                                            Active

                                                                            Legal Profile</h6>

                                                                    </div>

                                                                    <div class="card-body">



                                                                        <input type="hidden" id="edit_ID" name="edit_ID"

                                                                            readonly="true"

                                                                            value="<?= $edit_id ?>" />



                                                                        <div class="mb-3">

                                                                            <label class="form-label">

                                                                                Date:<span

                                                                                    class="asterisk text-danger">*</span>

                                                                            </label>

                                                                            <input type="date" class="form-control"

                                                                                id="dateon" name="dateon"

                                                                                value="<?= $data["dateon"] ?>"

                                                                                autocomplete="off" required />

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label" for="code">

                                                                                Code:<span

                                                                                    class="asterisk text-danger">*</span>

                                                                            </label>

                                                                            <input type="text" class="form-control"

                                                                                readonly="true" id="code" name="code"

                                                                                value="<?= $data["code"] ?>"

                                                                                autocomplete="off" required />

                                                                        </div>

                                                                        <?php if ($edit_id) { ?>
                                                                            <div class="mb-3">

                                                                                <?php if ($data["ClientType"] == 'M') { ?>
                                                                                    <label>
                                                                                        <input type="radio" name="which_type_user" value="marketing" checked />
                                                                                        Marketing
                                                                                    </label>
                                                                                <?php } else if ($data["ClientType"] == 'I') { ?>
                                                                                    <label style="margin-left:15px;">
                                                                                        <input type="radio" name="which_type_user" value="internal" checked />
                                                                                        Internal Staff
                                                                                    </label>
                                                                                <?php } ?>
                                                                            </div>

                                                                        <?php } else { ?>
                                                                            <div class="mb-3">
                                                                                <label>
                                                                                    <input type="radio" name="which_type_user" value="marketing" checked />
                                                                                    Marketing
                                                                                </label>

                                                                                <label style="margin-left:15px;">
                                                                                    <input type="radio" name="which_type_user" value="internal" />
                                                                                    Internal Staff
                                                                                </label>
                                                                            </div>

                                                                        <?php } ?>

                                                                        <div id="marketingStaff">
                                                                            <div class="mb-3">
                                                                                <label class="form-label" for="select_marketing"> Marketing:<span class="asterisk text-danger">*</span>
                                                                                </label>
                                                                                <select class="form-select select2-bootstrap" id="select_marketing" name="select_marketing" <?= $isEdit ? 'disabled' : '' ?> required>

                                                                                    <option value="">Select</option>
                                                                                    <?php if ($array_users): ?>
                                                                                        <?php foreach ($array_users as $user):
                                                                                            $selected = ($data["user_id"] == $user["user_Id"]) ? "selected" : "";
                                                                                        ?>
                                                                                            <option value="<?= $user["user_Id"] ?>" <?= $selected ?>>
                                                                                                <?= $user["user_name"] ?> - <?= $user["usertype_title"] ?>
                                                                                            </option>
                                                                                        <?php endforeach; ?>
                                                                                    <?php endif; ?>
                                                                                </select>

                                                                                <?php if ($isEdit): ?>
                                                                                    <input type="hidden" name="select_marketing" value="<?= $data["user_id"] ?>">
                                                                                <?php endif; ?>

                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label w-100" for="select_client"> Client:<span class="asterisk text-danger">*</span>
                                                                                    <?php if (!$isEdit): ?>
                                                                                        <a href="javascript:void(0);" onclick="openAddClientModal('marketing')" class="float-end btn btn-sm btn-outline-primary py-0"><i class="lni lni-plus"></i> Add External Client</a>
                                                                                    <?php endif; ?>
                                                                                </label>

                                                                                <select
                                                                                    class="form-select select2-bootstrap"
                                                                                    id="select_client"
                                                                                    name="select_client"
                                                                                    <?= $isEdit ? 'disabled' : '' ?>>
                                                                                    <option value="">Select Client</option>
                                                                                </select>

                                                                                <?php if ($isEdit): ?>
                                                                                    <input type="hidden" id="select_client_hidden" name="select_client" value="<?= $data['client'] ?? '' ?>">
                                                                                <?php endif; ?>

                                                                            </div>
                                                                        </div>

                                                                        <div id="internalStaff">
                                                                            <div class="mb-3">
                                                                                <label class="form-label">Internal Staff: <span
                                                                                        class="asterisk text-danger">*</span></label>
                                                                                <select class="form-select select2-bootstrap" id="select_internal"
                                                                                    name="select_internal" <?= $isEdit ? 'disabled' : '' ?>>
                                                                                    <option value="">Select </option>
                                                                                    <?php
                                                                                    if ($array_internal_staff) {
                                                                                        foreach ($array_internal_staff as $internal_staff_rows) {
                                                                                            $selected = ($data["user_id"] == $internal_staff_rows["user_Id"]) ? "selected" : "";
                                                                                    ?>
                                                                                            <option value="<?= $internal_staff_rows['user_Id'] ?>" <?= $selected ?>>
                                                                                                <?= $internal_staff_rows['user_name'] ?>
                                                                                            </option>
                                                                                    <?php
                                                                                        }
                                                                                    } ?>
                                                                                </select>
                                                                                <?php if ($isEdit): ?>
                                                                                    <input type="hidden" name="select_internal" value="<?= $data["user_id"] ?>">
                                                                                <?php endif; ?>
                                                                            </div>

                                                                            <div class="mb-3">
                                                                                <label class="form-label w-100" for="select_Internalclient"> Client:<span class="asterisk text-danger">*</span>
                                                                                    <?php if (!$isEdit): ?>
                                                                                        <a href="javascript:void(0);" onclick="openAddClientModal('internal')" class="float-end btn btn-sm btn-outline-primary py-0"><i class="lni lni-plus"></i> Add External Client</a>
                                                                                    <?php endif; ?>
                                                                                </label>

                                                                                <select
                                                                                    class="form-select select2-bootstrap"
                                                                                    id="select_Internalclient"
                                                                                    name="select_Internalclient"
                                                                                    <?= $isEdit ? 'disabled' : '' ?>>
                                                                                    <option value="">Select Client</option>
                                                                                </select>

                                                                                <?php if ($isEdit): ?>
                                                                                    <input type="hidden" id="select_client_hidden" name="select_Internalclient" value="<?= $data['client'] ?? '' ?>">
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>


                                                                        <div class="mb-3">

                                                                            <label class="form-label" for="category">

                                                                                Category:<span

                                                                                    class="asterisk text-danger">*</span>

                                                                            </label>

                                                                            <select

                                                                                class="form-select select2-bootstrap"

                                                                                id="category" name="category" required>

                                                                                <option value="">Select</option>

                                                                                <option value="<?= THIRD_PARTY_C_ID ?>">

                                                                                    Third Party</option>

                                                                                <option value="<?= LEGAL_FIRM_C_ID ?>">

                                                                                    Legal Firm</option>

                                                                                <option

                                                                                    value="<?= DEBT_COLLECTOR_C_ID ?>">

                                                                                    Debt Collector</option>

                                                                                <option value="<?= LEGAL_TEAM_C_ID ?>">

                                                                                    Legal Team</option>

                                                                            </select>

                                                                        </div>



                                                                        <div class="mb-3">

                                                                            <label class="form-label" for="agencies_id">

                                                                                Firm/Party/Debt/Legal:<span

                                                                                    class="asterisk text-danger">*</span>

                                                                            </label>

                                                                            <select

                                                                                class="form-select select2-bootstrap"

                                                                                id="agencies_id" name="agencies_id"

                                                                                required>

                                                                                <option value="">Select</option>

                                                                            </select>

                                                                        </div>



                                                                        <div class="mb-3">

                                                                            <label class="form-label"

                                                                                for="notes">Notes:</label>

                                                                            <textarea class="form-control" rows="2"

                                                                                id="notes"

                                                                                name="notes"><?= $data["notes"] ?></textarea>

                                                                        </div>



                                                                    </div>

                                                                </div>

                                                            </div>

                                                        </div>

                                                        <div class="col-lg-6">

                                                            <div class="col">

                                                                <!-- Outstanding Card -->

                                                                <div class="card">

                                                                    <div class="card-header">

                                                                        <h6 class="mb-0">

                                                                            <i class="lni lni-text-align-justify"></i> Outstanding

                                                                        </h6>

                                                                    </div>

                                                                    <div class="card-body">

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Total Outstanding:</label>

                                                                            <input type="number" class="form-control"

                                                                                id="total_outstanding" step="any"

                                                                                name="total_outstanding"

                                                                                value="<?= $data['total_outstanding'] ?>" required />

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Outstanding with cheque:</label>

                                                                            <input type="number" class="form-control"

                                                                                id="outstanding_with_cheque" step="any"

                                                                                name="outstanding_with_cheque"

                                                                                value="<?= $data['outstanding_with_cheque'] ?>" readonly />

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Outstanding with Invoice:</label>

                                                                            <input type="number" class="form-control"

                                                                                id="outstanding_without_cheque" step="any"

                                                                                name="outstanding_without_cheque"

                                                                                value="<?= $data['outstanding_without_cheque'] ?>" readonly />

                                                                        </div>

                                                                    </div>

                                                                </div>
                                                                <div class="mb-3">
                                                                    <input type="hidden" id="csrf_token" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>" readonly="true" />
                                                                    <input type="hidden" id="hid_module" name="hid_module" value="<?= $_GET['module']; ?>" readonly="true" />
                                                                    <input type="hidden" id="hid_page" name="hid_page" value="<?= $_GET['page']; ?>" readonly="true" />
                                                                    <input type="hidden" id="active_legal" name="active_legal" value="<?= $_GET['param1']; ?>" readonly="true" />
                                                                    <input type="hidden" name="selected_client_id" id="selected_client_id">

                                                                </div>



                                                                <div class="card mt-3">
                                <div class="card-header">
                                  <h6 class="mb-0"><i class="lni lni-revenue"></i> Paid Court Fees & Expenses</h6>
                                </div>
                                <div class="card-body">
                                  <div id="ExpenseResponseMessage" class="mt-2"></div>
                                  <div class="row g-2 align-items-end mb-3">
                                    <div class="col-md-5">
                                      <label class="form-label">Fee Type</label>
                                      <select class="form-select" id="new_expense_type" onchange="toggleOtherExpense()">
                                        <option value="">Select Fee Type</option>
                                        <option value="Court Filing Case fees">Court Filing Case fees</option>
                                        <option value="Expert fee">Expert fee</option>
                                        <option value="Announcement fee">Announcement fee</option>
                                        <option value="Emirates Judgment Enforcement fee (EJE)">Emirates Judgment Enforcement fee (EJE)</option>
                                        <option value="Notary Public Fee">Notary Public Fee</option>
                                        <option value="Other expense">Other expense</option>
                                      </select>
                                    </div>
                                    <div class="col-md-4">
                                      <label class="form-label">Amount</label>
                                      <input type="number" class="form-control" id="new_expense_amount" step="0.01" placeholder="0.00">
                                    </div>
                                    <div class="col-md-3">
                                      <button type="button" class="btn btn-primary w-100" onclick="addClientExpense('<?= $edit_id ?>')">
                                        <i class="bx bx-plus"></i> Add
                                      </button>
                                    </div>
                                    <div class="col-12 mt-2" id="other_expense_reason_div" style="display: none;">
                                      <label class="form-label">Expense Reason</label>
                                      <input type="text" class="form-control" id="new_expense_reason" placeholder="Enter reason for other expense">
                                    </div>
                                  </div>

                                  <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                      <thead class="table-light">
                                        <tr>
                                          <th>Fee Type / Reason</th>
                                          <th class="text-end">Amount</th>
                                          <th class="text-center">Action</th>
                                        </tr>
                                      </thead>
                                      <tbody id="client_expenses_list">
                                        <!-- Expenses will be loaded here -->
                                      </tbody>
                                      <tfoot>
                                        <tr class="table-light">
                                          <th>Total Expenses</th>
                                          <th class="text-end" id="total_expenses_sum">0.00</th>
                                          <th></th>
                                        </tr>
                                      </tfoot>
                                    </table>
                                  </div>

                                  <div class="mt-3 border-top pt-3">
                                    <label class="form-label fw-bold text-primary">Total Claim Amount:</label>
                                    <input type="number" class="form-control fw-bold text-primary" value="0.00" id="total_claim_amount"  />
                                  </div>
                                </div>
                              </div>













                                                                <!-- Claim & Expense Card -->

                                                                <div class="card">

                                                                    <div class="card-header">

                                                                        <h6 class="mb-0">

                                                                            <i class="lni lni-text-align-justify"></i>

                                                                        </h6>

                                                                    </div>

                                                                    <div class="card-body">

                                                                        <div class="mb-3">
                                                                            <label class="form-label">Client Outstanding Reference:</label>
                                                                            <input type="text" class="form-control"
                                                                                id="outstanding_reference"
                                                                                value="<?= $data['total_outstanding'] ?>" readonly />
                                                                            <small class="text-muted">Total balance based on cheques.</small>
                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Claim Amount:</label>

                                                                            <input type="number" class="form-control"

                                                                                id="claim_amount" step="any"

                                                                                name="claim_amount"

                                                                                value="<?= $data['claim_amount'] ?>" />
                                                                            <small id="claim_warning" class="text-danger" style="display:none;">Claim amount cannot be less than the collected amount.</small>

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Collected Amount:</label>

                                                                            <input type="text" class="form-control"

                                                                                id="collected_amount"

                                                                                name="collected_amount"

                                                                                value="<?= $data['total_collection'] ?? 0 ?>" readonly />

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Balance to Collect:</label>

                                                                            <input type="text" class="form-control"

                                                                                id="balance_claim"

                                                                                name="balance_claim"

                                                                                value="<?= $data['claim_amount'] - $data['total_collection'] ?>" readonly />

                                                                        </div>

                                                                        <div class="mb-3">

                                                                            <label class="form-label">Expense Amount:</label>

                                                                            <input type="text" class="form-control"

                                                                                id="expense_amount"

                                                                                name="expense_amount"

                                                                                value="<?= $data['total_Expense'] ?? 0 ?>" readonly />

                                                                        </div>

                                                                    </div>

                                                                </div>

                                                                <!-- list cheque -->

                                                                <div class="col">

                                                                    <div class="card">
                                                                        <div class="card-header">
                                                                            <h6 class="mb-0"><i class="lni lni-indent-increase"></i>
                                                                                Cheque List</h6>
                                                                        </div>
                                                                        <div class="card-body">
                                                                            <form>
                                                                                <div class="mb-3">
                                                                                    <div class="table-responsive mt-3">
                                                                                        <table class="table align-middle mb-0">
                                                                                            <thead class="table-light">
                                                                                                <tr>
                                                                                                    <td>Sl No</td>
                                                                                                    <td>Cheque date</td>
                                                                                                    <td>Amount</td>
                                                                                                    <td>Documents</td>
                                                                                                    <td></td>
                                                                                                </tr>
                                                                                            </thead>
                                                                                            <tbody id="cheque_table_body">
                                                                                                <tr>
                                                                                                    <td class='text-center' colspan='4'>Loading cheques ...</td>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>

                                                                                </div>

                                                                            </form>
                                                                        </div>
                                                                    </div>

                                                                </div>



                                                            </div>

                                                        </div>





                                                        <div class="row justify-content-center">

                                                            <div class="mb-4 d-flex justify-content-center">

                                                                <button type="submit"

                                                                    class="btn btn-primary px-5 mx-2" id="btn_save" disabled>Save</button>

                                                                <button type="reset"

                                                                    class="btn btn-secondary px-5 mx-2">Reset</button>

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </section>

                                </form>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- end page content-->





    <div class="modal fade" id="exampleExtraLargeModal" tabindex="-1" aria-hidden="true">

        <div class="modal-dialog modal-xl">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title"><i class="lni lni-plus"></i> Add Contacts</h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">





                </div>

                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

                    <button type="button" class="btn btn-primary">Save changes</button>

                </div>

            </div>

        </div>

    </div>

    <!-- Add External Client Modal -->
    <div class="modal fade" id="addExternalClientModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="lni lni-plus"></i> Add External Client</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="ext_client_type" value="">
                    <div class="mb-3">
                        <label class="form-label">Client Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="ext_client_name" placeholder="Enter External Client Name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="btnSaveExtClient">Save Client</button>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- Toast Container -->
<div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
    <div id="statusToast" class="toast align-items-center text-white bg-success border-0" role="alert">
        <div class="d-flex">
            <div class="toast-body" id="statusToastBody">
                Status updated successfully!
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    function openAddClientModal(type) {
        let staffId = '';
        if (type === 'marketing') {
            staffId = $('#select_marketing').val();
            if (!staffId) {
                alert('Please select Marketing staff first');
                return;
            }
        } else {
            staffId = $('#select_internal').val();
            if (!staffId) {
                alert('Please select Internal staff first');
                return;
            }
        }
        
        $('#ext_client_type').val(type);
        $('#ext_client_name').val('');
        $('#addExternalClientModal').modal('show');
    }

    $(document).ready(function() {
        $('#btnSaveExtClient').click(function() {
            const clientName = $('#ext_client_name').val().trim();
            const type = $('#ext_client_type').val();
            let staffId = '';
            
            if (type === 'marketing') {
                staffId = $('#select_marketing').val();
            } else {
                staffId = $('#select_internal').val();
            }
            
            if (!clientName) {
                alert('Please enter client name');
                return;
            }

            const btn = $(this);
            btn.prop('disabled', true).text('Saving...');
            
            $.ajax({
                type: 'POST',
                url: '<?= ROOT_DIR ?>modules/client/ajax/save_external_client.php',
                data: {
                    marketing_id: staffId,
                    client_name: clientName
                },
                dataType: 'json',
                success: function(response) {
                    btn.prop('disabled', false).text('Save Client');
                    if (response.success) {
                        $('#addExternalClientModal').modal('hide');
                        
                        // Refresh the corresponding client list and select the new one
                        if (type === 'marketing') {
                            listClient(staffId, response.client_id);
                        } else {
                            listInternal(staffId, response.client_id);
                        }
                        
                        const toastEl = document.getElementById('statusToast');
                        const toastBody = document.getElementById('statusToastBody');
                        const toast = new bootstrap.Toast(toastEl);
                        toastBody.textContent = response.message;
                        toastEl.classList.remove('bg-danger');
                        toastEl.classList.add('bg-success');
                        toast.show();
                    } else {
                        alert(response.message);
                    }
                },
                error: function() {
                    btn.prop('disabled', false).text('Save Client');
                    alert('Error occurred while adding client.');
                }
            });
        });

        function toggleUserType() {
            const type = $('input[name="which_type_user"]:checked').val();
            if (type === 'marketing') {
                $('#marketingStaff').show();
                $('#internalStaff').hide();

            } else if (type === 'internal') {
                $('#marketingStaff').hide();
                $('#internalStaff').show();

            }
        }

        // Run on page load (IMPORTANT for edit)
        toggleUserType();

        // Run when radio changes
        $('input[name="which_type_user"]').on('change', toggleUserType);

        /* Load Client list  */
        $('#select_marketing').change(function() {

            const marketingId = $(this).val();

            listClient(marketingId);

        });

        $('#select_internal').change(function() {

            const internalId = $(this).val();

            listInternal(internalId);

        });


        $('#category').change(function() {

            const id = $(this).val();

            listcategories(id, '');

        });
    });


    $('#btn_save').click(function(event) {
        event.preventDefault();

        const edit_ID = $('#edit_ID').val();

        const dateon = $('#dateon').val();
        if (!dateon) {
            alert('Please select Date');
            return;
        }

        const whichTypeUser = $('input[name="which_type_user"]:checked').val();

        let ajaxData = {
            edit_ID: edit_ID,
            which_type_user: whichTypeUser
        };


        if (whichTypeUser === 'marketing') {

            const select_marketing = $('#select_marketing').val();
            const selectedClientId = $('#select_client').val();

            if (!select_marketing || !selectedClientId) {
                alert('Please select Marketing and Client');
                return;
            }

            ajaxData.select_marketing = select_marketing;
            ajaxData.selectedClientId = selectedClientId;

        } else if (whichTypeUser === 'internal') {

            const select_internal = $('#select_internal').val();
            const select_Internalclient = $('#select_Internalclient').val();

            if (!select_internal || !select_Internalclient) {
                alert('Please select Internal Staff and Client');
                return;
            }

            ajaxData.select_internal = select_internal;
            ajaxData.select_Internalclient = select_Internalclient;
        }

        $.ajax({
            type: 'post',
            url: '<?= ROOT_DIR ?>modules/activelegaldemo/ajax/check_active_legal.php',
            data: ajaxData,
            success: function(jsonResponse) {
                let response = JSON.parse(jsonResponse);

                if (!response.is_unique) {
                    const toastEl = document.getElementById('statusToast');
                    const toastBody = document.getElementById('statusToastBody');
                    const toast = new bootstrap.Toast(toastEl);

                    toastBody.textContent = response.message;
                    toastEl.classList.remove('bg-success');
                    toastEl.classList.add('bg-danger');
                    toast.show();

                    return;
                }

                // Financial validation
                const claimAmt = parseFloat($('#claim_amount').val()) || 0;
                const collectedAmt = parseFloat($('#collected_amount').val()) || 0;
                if (claimAmt < collectedAmt) {
                    alert('Claim Amount cannot be less than the Collected Amount ($' + collectedAmt.toFixed(2) + ')');
                    $('#claim_amount').addClass('is-invalid').focus();
                    return;
                }

                $('#frm_activelegal_information')
                    .off('submit')
                    .submit();
            }
        });

    });

    function listInternal(internalId, clientId, skipAutofill = false) {

        // return;


        // Clear previous items

        $('#select_Internalclient').html('<option value="">-- Select Client --</option>');

        const selectedClientId = clientId; // Replace with the value you want to select

        if (internalId) {

            $.ajax({

                url: '<?= ROOT_DIR ?>modules/client/ajax/get_client.php', // Adjust as needed

                type: 'POST',

                data: {
                    marketingId: internalId,
                    action: 'client_legal_list'
                },

                dataType: 'json',

                success: function(response) {


                    $(document).ready(function() {
                        $('#select_Internalclient').empty(); // Clear previous options

                        // Add default option
                        $('#select_Internalclient').append('<option value="">--- Select Client ---</option>');

                        if (Array.isArray(response) && response.length > 0) {
                            // Populate dropdown with client options
                            response.forEach(item => {

                                const selected = String(item.id) === String(selectedClientId) ? 'selected="selected"' : '';
                                $('#select_Internalclient').append(`<option value="${item.id}" ${selected}>${item.name}</option>`);
                            });

                            $('#select_Internalclient').on('change', function() {
                                const selectedId = $(this).val();
                                $('#selected_client_id').val(selectedId);
                                loadCheque();
                                if (skipAutofill) {
                                    skipAutofill = false;
                                    return;
                                }
                                if (!selectedId) {
                                    // Default option selected
                                    $('#total_outstanding').val(0);
                                    // $('#outstanding_with_cheque').val(0);
                                    // $('#outstanding_without_cheque').val(0);
                                    $('#claim_amount').val(0);
                                    return;
                                }
                                const selectedItem = response.find(item => String(item.id) === selectedId);
                                if (!selectedItem) {
                                    $('#total_outstanding').val(0);
                                    // $('#outstanding_with_cheque').val(0);
                                    // $('#outstanding_without_cheque').val(0);
                                    $('#claim_amount').val(0);
                                    return;
                                }
                                $('#total_outstanding').val(selectedItem.total_outstanding ?? 0).trigger('change');
                                // These are now handled by loadCheque() dynamically
                                // $('#outstanding_with_cheque').val(selectedItem.outstanding_cheque ?? 0).trigger('change');
                                // $('#outstanding_without_cheque').val(selectedItem.outstanding_without_cheque ?? 0).trigger('change');
                            });

                            // Set initial selection and trigger change
                            const isValidSelectedId = selectedClientId && response.some(item => String(item.id) === String(selectedClientId));
                            if (isValidSelectedId) {
                                $('#select_Internalclient').val(String(selectedClientId)).trigger('change');
                            } else {
                                $('#select_Internalclient').val(''); // Select default option
                                $('#total_outstanding').val(0);
                                $('#outstanding_with_cheque').val(0);
                                $('#outstanding_without_cheque').val(0);
                                $('#claim_amount').val(0);
                            }
                        } else {
                            $('#total_outstanding').val(0);
                            $('#outstanding_with_cheque').val(0);
                            $('#outstanding_without_cheque').val(0);
                            $('#claim_amount').val(0);
                        }
                    });

                },

                error: function(xhr, status, error) {

                    console.error('Error:', error);

                }

            });

        }

    }


    function loadCheque() {
        let csrf_token = $("#csrf_token").val()
        let hid_module = $("#hid_module").val()
        let hid_page = $("#hid_page").val()
        let active_legal = $("#active_legal").val()
        let selected_client_id = $("#selected_client_id").val()


        $.ajax({
            type: 'post',
            url: '<?= ROOT_DIR ?>modules/case/ajax/load_ajax_cheque.php',
            data: {
                hid_module,
                hid_page,
                csrf_token,
                active_legal,
                selected_client_id
            },
            success: function(jsonResponse) {
                let response = JSON.parse(jsonResponse)
                $("#cheque_table_body").html(response.message)
                if (response.success) {
                    $('#outstanding_with_cheque').val(response.total_with_cheque || 0).trigger('change');
                    $('#outstanding_without_cheque').val(response.total_without_cheque || 0).trigger('change');
                }
            },
            error: function(err) {
                console.log(err)
            }
        })
    }

    function listClient(marketingId, clientId, skipAutofill = false) {



        // Clear previous items

        $('#select_client').html('<option value="">-- Select Client --</option>');

        const selectedClientId = clientId; // Replace with the value you want to select

        if (marketingId) {

            $.ajax({

                url: '<?= ROOT_DIR ?>modules/client/ajax/get_client.php', // Adjust as needed

                type: 'POST',

                data: {
                    marketingId: marketingId,
                    action: 'client_legal_list'
                },

                dataType: 'json',

                success: function(response) {

                    // console.log(response);

                    // if (Array.isArray(response)) {

                    //     response.forEach(item => {

                    //         const selected = item.id === selectedClientId ? 'selected="selected"' : '';

                    //         $('#select_client').append(`<option value="${item.id}" ${selected}>${item.name}</option>`);

                    //     });

                    // } else {

                    //     $('#select_client').append('<option value="">No items found</option>');

                    // }

                    $(document).ready(function() {
                        $('#select_client').empty(); // Clear previous options

                        // Add default option
                        $('#select_client').append('<option value="">--- Select Client ---</option>');

                        if (Array.isArray(response) && response.length > 0) {
                            // Populate dropdown with client options
                            response.forEach(item => {

                                const selected = String(item.id) === String(selectedClientId) ? 'selected="selected"' : '';
                                $('#select_client').append(`<option value="${item.id}" ${selected}>${item.name}</option>`);
                            });

                            $('#select_client').on('change', function() {
                                const selectedId = $(this).val();
                                $('#selected_client_id').val(selectedId);
                                loadCheque();
                                if (skipAutofill) {
                                    skipAutofill = false;
                                    return;
                                }
                                if (!selectedId) {
                                    // Default option selected
                                    $('#total_outstanding').val(0);
                                    // $('#outstanding_with_cheque').val(0);
                                    // $('#outstanding_without_cheque').val(0);
                                    $('#claim_amount').val(0);
                                    return;
                                }
                                const selectedItem = response.find(item => String(item.id) === selectedId);
                                if (!selectedItem) {
                                    $('#total_outstanding').val(0);
                                    // $('#outstanding_with_cheque').val(0);
                                    // $('#outstanding_without_cheque').val(0);
                                    $('#claim_amount').val(0);
                                    return;
                                }
                                $('#total_outstanding').val(selectedItem.total_outstanding ?? 0).trigger('change');
                                // These are now handled by loadCheque() dynamically
                                // $('#outstanding_with_cheque').val(selectedItem.outstanding_cheque ?? 0).trigger('change');
                                // $('#outstanding_without_cheque').val(selectedItem.outstanding_without_cheque ?? 0).trigger('change');
                            });

                            // Set initial selection and trigger change
                            const isValidSelectedId = selectedClientId && response.some(item => String(item.id) === String(selectedClientId));
                            if (isValidSelectedId) {
                                $('#select_client').val(String(selectedClientId)).trigger('change');
                            } else {
                                $('#select_client').val(''); // Select default option
                                $('#total_outstanding').val(0);
                                $('#outstanding_with_cheque').val(0);
                                $('#outstanding_without_cheque').val(0);
                                $('#claim_amount').val(0);
                            }
                        } else {
                            $('#total_outstanding').val(0);
                            $('#outstanding_with_cheque').val(0);
                            $('#outstanding_without_cheque').val(0);
                            $('#claim_amount').val(0);
                        }
                    });

                },

                error: function(xhr, status, error) {

                    console.error('Error:', error);

                }

            });

        }

    }

    function listcategories(id, agencies_id) {

        // Clear previous items

        $('#agencies_id').html('<option value="">-- Select Category --</option>');



        if (id) {

            $.ajax({

                url: '<?= ROOT_DIR ?>ajax/get_agencies_list.php', // Adjust as needed

                type: 'POST',

                data: {
                    action: 'list',
                    id: id
                },

                dataType: 'json',

                success: function(response) {


                    if (Array.isArray(response)) {

                        response.forEach(item => {

                            const selected = item.id === agencies_id ? 'selected="selected"' : '';

                            $('#agencies_id').append(`<option value="${item.id}" ${selected}>${item.code ? item.code + ' - ' : ''}${item.name}</option>`);



                        });

                    } else {

                        $('#agencies_id').append('<option value="">No data found</option>');

                    }

                },

                error: function(xhr, status, error) {

                    console.error('Error:', error);

                }

            });

        }

    }
</script>

<script>
    const claimAmountInput = document.getElementById('claim_amount');
    const collectedAmountInput = document.getElementById('collected_amount');
    const balanceClaimInput = document.getElementById('balance_claim');
    
    const totalOutstandingInput = document.getElementById('total_outstanding');
    const withChequeInput = document.getElementById('outstanding_with_cheque');
    const withoutChequeInput = document.getElementById('outstanding_without_cheque');

    function updateBalance() {
        const claimAmount = parseFloat(claimAmountInput.value) || 0;
        const collectedAmount = parseFloat(collectedAmountInput.value) || 0;
        const balance = claimAmount - collectedAmount;
        
        if (balance < 0) {
            $(claimAmountInput).addClass('is-invalid');
            $('#claim_warning').show();
        } else {
            $(claimAmountInput).removeClass('is-invalid');
            $('#claim_warning').hide();
        }
        
        balanceClaimInput.value = balance >= 0 ? balance.toFixed(2) : 0;
    }

    function updateOutstanding() {
        const withCheque = parseFloat(withChequeInput.value) || 0;
        const withoutCheque = parseFloat(withoutChequeInput.value) || 0;
        const total = withCheque + withoutCheque;
        totalOutstandingInput.value = total.toFixed(2);
        document.getElementById('outstanding_reference').value = total.toFixed(2);
        updateTotalClaimAmount();
    }

    function toggleOtherExpense() {
        const type = document.getElementById('new_expense_type').value;
        const div = document.getElementById('other_expense_reason_div');
        if (type === 'Other expense') {
            div.style.display = 'block';
        } else {
            div.style.display = 'none';
            document.getElementById('new_expense_reason').value = '';
        }
    }

    function loadClientExpenses(clientId) {
        if (!clientId) return;
        fetch(`<?= ROOT_DIR ?>ajax/manage_client_expenses.php?action=get_expenses&client_id=${clientId}`)
            .then(response => response.json())
            .then(result => {
                if (result.status === "success") {
                    const list = document.getElementById('client_expenses_list');
                    list.innerHTML = '';
                    let total = 0;
                    result.data.forEach(exp => {
                        total += parseFloat(exp.amount);
                        const row = `
                            <tr>
                                <td>${exp.description} ${exp.remark ? ' (' + exp.remark + ')' : ''}</td>
                                <td class="text-end">${parseFloat(exp.amount).toFixed(2)}</td>
                                <td class="text-center">
                                    <button type="button" class="btn btn-sm btn-danger" onclick="deleteClientExpense('${exp.id}', '${clientId}')">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                        list.innerHTML += row;
                    });
                    document.getElementById('total_expenses_sum').innerText = total.toFixed(2);
                    updateTotalClaimAmount();
                }
            });
    }

    function addClientExpense(clientId) {

const type = document.getElementById('new_expense_type').value;
const amount = parseFloat(document.getElementById('new_expense_amount').value) || 0;
const reason = document.getElementById('new_expense_reason').value;

if (!type || amount <= 0) {
    alert("Please select fee type and enter amount.");
    return;
}

let expenseTitle = type;

if (type === "Other expense" && reason !== '') {
    expenseTitle += " - " + reason;
}

// Add row into table only
let row = `
    <tr>
        <td>${expenseTitle}</td>
        <td class="text-end">${amount.toFixed(2)}</td>
        <td class="text-center">
            <button class="bx bx-trash"
                onclick="removeExpense(this, ${amount})">
                Delete
            </button>
        </td>
    </tr>
`;

document.getElementById('client_expenses_list')
    .insertAdjacentHTML('beforeend', row);

// Update total expenses
let totalExpenses = parseFloat(
    document.getElementById('total_expenses_sum').innerText
) || 0;

totalExpenses += amount;

document.getElementById('total_expenses_sum').innerText =
    totalExpenses.toFixed(2);

// Update total claim amount
let claimAmount = parseFloat(
    document.getElementById('total_claim_amount').value
) || 0;

claimAmount += amount;

document.getElementById('total_claim_amount').value =
    claimAmount.toFixed(2);

// Clear fields
document.getElementById('new_expense_type').value = '';
document.getElementById('new_expense_amount').value = '';
document.getElementById('new_expense_reason').value = '';

toggleOtherExpense();
}
    function deleteClientExpense(expenseId, clientId) {
        if (!confirm("Are you sure you want to delete this expense?")) return;
        const data = {
            action: 'delete_expense',
            expense_id: expenseId
        };
        fetch("<?= ROOT_DIR ?>ajax/manage_client_expenses.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.status === "success") {
                    loadClientExpenses(clientId);
                } else {
                    alert(result.message);
                }
            });
    }

    function updateTotalClaimAmount() {
        // const outstanding = parseFloat(totalOutstandingInput.value) || 0;
        const expenses = parseFloat(document.getElementById('total_expenses_sum').innerText) || 0;
        const totalClaim = expenses;
        document.getElementById('total_claim_amount').value = totalClaim.toFixed(2);
        
        // Update the main Claim Amount field
        claimAmountInput.value = totalClaim.toFixed(2);
        updateBalance();
    }

    claimAmountInput.addEventListener('input', updateBalance);
    collectedAmountInput.addEventListener('input', updateBalance);
    
    withChequeInput.addEventListener('input', updateOutstanding);
    withoutChequeInput.addEventListener('input', updateOutstanding);
    
    // Also trigger on change for when values are set via JS
    $(claimAmountInput).on('change', updateBalance);
    $(collectedAmountInput).on('change', updateBalance);
    
    $(withChequeInput).on('change', updateOutstanding);
    $(withoutChequeInput).on('change', updateOutstanding);

    // Initial load for expenses
    $(document).ready(function() {
        const editId = '<?= $edit_id ?>';
        if (editId) {
            loadClientExpenses(editId);
        }
    });
</script>

<?php if ($action == "edit" && $edit_id > 0 && $data['user_id'] > 0 && $data['category'] > 0) { ?>

    <script>
        $('#select_marketing').val(<?= $data['user_id'] ?>).trigger('change');

        listClient('<?= $data['user_id'] ?>', '<?= $data['client'] ?>', true);
        $('#select_internal').val(<?= $data['user_id'] ?>).trigger('change');
        listInternal('<?= $data['user_id'] ?>', '<?= $data['client'] ?>', true);

        $('#category').val('<?= $data['category'] ?>').trigger('change');

        listcategories('<?= $data['category'] ?>', '<?= $data['agencies_id'] ?>');
    </script>

<?php

}

?>